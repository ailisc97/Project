CarparkData <- read.csv(file="CarparkData.csv", head=TRUE, sep = ",")
#TotalNew <- read.csv(file = "TotalNew.csv", head=TRUE, sep=",")
#Changing the name of the title
colnames(CarparkData)[colnames(CarparkData)=="X409"] <-"Parnell"
colnames(CarparkData)[colnames(CarparkData)=="X903"] <-"Ilac"
colnames(CarparkData)[colnames(CarparkData)=="X764"] <-"Jervis"
colnames(CarparkData)[colnames(CarparkData)=="X359"] <-"Arnotts"
colnames(CarparkData)[colnames(CarparkData)=="X352"] <-"Malboro"
colnames(CarparkData)[colnames(CarparkData)=="X"] <-"Abbey"
colnames(CarparkData)[colnames(CarparkData)=="X238"] <-"Thomas"
#colnames(CarparkData)[colnames(CarparkData)=="Thomas Street"] <-"Thomas"
#colnames(CarparkData)[colnames(CarparkData)=="Christ Church"] <-"ChristC"
colnames(CarparkData)[colnames(CarparkData)=="X64"] <-"ChristC"
colnames(CarparkData)[colnames(CarparkData)=="X120"] <-"Setanta"
colnames(CarparkData)[colnames(CarparkData)=="X317"] <-"Dawson"
colnames(CarparkData)[colnames(CarparkData)=="X267"] <-"Trinity"
colnames(CarparkData)[colnames(CarparkData)=="X.1"] <-"Greenrcs"
colnames(CarparkData)[colnames(CarparkData)=="X443"] <-"Drury"
colnames(CarparkData)[colnames(CarparkData)=="X287"] <-"BrownT"
#colnames(CarparkData)[colnames(CarparkData)=="Brown Thomas"] <-"BrownT"
colnames(CarparkData)[colnames(CarparkData)=="X2019.03.18.18.00.59"] <-"Date_Time"
#Subset
CarparkData <- CarparkData [,-6]
#CarparkDataNew <- CarparkData [, -6]
# Sorting out the duplicates
duplicated(CarparkData)
CarparkData <- CarparkData[!duplicated(CarparkData), ]

#Addressing N/A & Full

#Ilac <- CarparkDataTEST$Ilac
#Ilac
#is.na(Ilac)
#which(is.na(Ilac))

#Ilac[which(is.na(Ilac))] <-1

CarparkData$Ilac <- as.numeric(as.character(CarparkData$Ilac))
CarparkData$Ilac[which(is.na(CarparkData$Ilac))] <-1000
mean(CarparkData$Ilac)

CarparkData$Jervis <- as.numeric(as.character(CarparkData$Jervis))
CarparkData$Jervis[which(is.na(CarparkData$Jervis))] <-750
mean(CarparkData$Jervis)

CarparkData$Arnotts <- as.numeric(as.character(CarparkData$Arnotts))
CarparkData$Arnotts[which(is.na(CarparkData$Arnotts))] <-358
mean(CarparkData$Arnotts)

CarparkData$Thomas <- as.numeric(as.character(CarparkData$Thomas))
CarparkData$Thomas[which(is.na(CarparkData$Thomas))] <-238
mean(CarparkData$Thomas)

CarparkData$ChristC <- as.numeric(as.character(CarparkData$ChristC))
CarparkData$ChristC[which(is.na((CarparkData$ChirstC)))] <-212
mean(CarparkData$ChristC)

CarparkData$Setanta <- as.numeric(as.character(CarparkData$Setanta)) 
CarparkData$Setanta[which(is.na((CarparkData$Setanta)))] <-146
mean(CarparkData$Setanta)

CarparkData$Dawson <- as.numeric(as.character(CarparkData$Dawson))
CarparkData$Dawson[which(is.na((CarparkData$Dawson)))] <-370

CarparkData$Trinity <- as.numeric(as.character(CarparkData$Trinity))
CarparkData$Trinity[which(is.na((CarparkData$Trinity)))] <-180

CarparkData$Greenrcs <- as.numeric(as.character(CarparkData$Greenrcs)) 
CarparkData$Greenrcs[which(is.na((CarparkData$Greenrcs)))] <-1200

CarparkData$Drury<- as.numeric(as.character(CarparkData$Drury))
CarparkData$Drury[which(is.na((CarparkData$Drury)))] <-500

CarparkData$BrownT <- as.numeric(as.character(CarparkData$BrownT))
CarparkData$BrownT[which(is.na((CarparkData$BrownT)))] <-378

CarparkData$Parnell <- as.numeric(as.character(CarparkData$Parnell))
CarparkData$Parnell[which(is.na((CarparkData$Parnell)))] <-500

duplicated(CarparkData)
CarparkData <- CarparkData[!duplicated(CarparkData),]

#Writing the CarparkData into .csv for Tableau
#write.csv(CarparkData, "Total.csv")

#Exploratory Data Analysis
##ggplots against two different carparks.
library(tidyverse)
head(CarparkData)
summary(CarparkData)
ggplot(CarparkData, aes(x=Parnell, y=Ilac)) + geom_point() +
  geom_jitter() + geom_smooth(method='lm')

ggplot(CarparkData, aes(x=Trinity, y=BrownT)) + geom_point() +
  geom_jitter() + geom_smooth(method='lm')

ggplot(CarparkData, aes(x=Jervis, y=Setanta)) + geom_point() +
  geom_jitter() + geom_smooth(method='lm')
#Histogram
hist(CarparkData$Parnell , prob=T, main = "The density of the Carpark Spaces in Parnell")
hist(CarparkData$Ilac, prob=T, main = "The density of the Carpark Spaces in Ilac")
hist(CarparkData$Jervis , prob=T, main = "The density of the Carpark Spaces in Jervis")
hist(CarparkData$Arnotts , prob=T, main = "The density of the Carpark Spaces in Arnotts")
hist(CarparkData$Malboro , prob=T, main = "The density of the Carpark Spaces in Marlboro")
hist(CarparkData$Thomas, prob=T, main = "The density of the Carpark Spaces in Thomas Street")
hist(CarparkData$ChristC, prob=T, main = "The density of the Carpark Spaces in Christ Church")
hist(CarparkData$Setanta, prob=T, main = "The density of the Carpark Spaces in Setanta")
hist(CarparkData$Dawson , prob=T, main = "The density of the Carpark Spaces in Dawson")
hist(CarparkData$Trinity , prob=T, main = "The density of the Carpark Spaces in Trinity")
hist(CarparkData$Greenrcs, prob=T, main = "The density of the Carpark Spaces in Greenrcs")
hist(CarparkData$Drury , prob=T, main = "The density of the Carpark Spaces in Drury")
hist(CarparkData$BrownT , prob=T, main = "The density of the Carpark Spaces in Brown Thomas")

#Q-Q plot
#install.packages("car")
library(car)
qqnorm(CarparkData$Parnell)
qqline(CarparkData$Parnell, col="red")

qqnorm(CarparkData$Ilac)
qqline(CarparkData$Ilac, col="red")

qqnorm(CarparkData$Jervis)
qqline(CarparkData$Jervis, col="red")

qqnorm(CarparkData$Arnotts)
qqline(CarparkData$Arnotts, col="red")

qqnorm(CarparkData$Malboro)
qqline(CarparkData$Malboro, col="blue")

qqnorm(CarparkData$Thomas)
qqline(CarparkData$Thomas, col="green")

qqnorm(CarparkData$ChristC)
qqline(CarparkData$ChristC, col="red")

qqnorm(CarparkData$Setanta)
qqline(CarparkData$Setanta, col="red")

qqnorm(CarparkData$Dawson)
qqline(CarparkData$Dawson, col="red")

qqnorm(CarparkData$Trinity)
qqline(CarparkData$Trinity, col="orange")

qqnorm(CarparkData$Greenrcs)
qqline(CarparkData$Greenrcs, col="brown")

qqnorm(CarparkData$Drury)
qqline(CarparkData$Drury, col="red")

qqnorm(CarparkData$BrownT)
qqline(CarparkData$BrownT, col="yellow")
#Going to conduct a log malic on the brown thomas car parking space
#As its is not as close to the line as parnell
log.malic <- log(CarparkData$Arnotts)
qqnorm(log.malic)
qqline(log.malic, col="red")
#closer to the line but it is approacting normal but it is not normal still.

#boxplot 
boxplot(CarparkData$Ilac)
abline(h=mean(CarparkData$Ilac, na.rn=T), lty=2)
boxplot(CarparkData$Parnell)
abline(h=mean(CarparkData$Parnell, na.rn=T), lty=2)
boxplot(CarparkData$Jervis)
abline(h=mean(CarparkData$Jervis, na.rn=T), lty=2)
boxplot(CarparkData$Arnotts)
abline(h=mean(CarparkData$Arnotts, na.rn=T), lty=2)
boxplot(CarparkData$Malboro)
abline(h=mean(CarparkData$Malboro, na.rn=T), lty=2)
boxplot(CarparkData$Thomas)
abline(h=mean(CarparkData$Thomas, na.rn=T), lty=2)
boxplot(CarparkData$ChristC)
abline(h=mean(CarparkData$ChristC, na.rn=T), lty=2)
boxplot(CarparkData$Setanta)
abline(h=mean(CarparkData$Setanta, na.rn=T), lty=2)
boxplot(CarparkData$Dawson)
abline(h=mean(CarparkData$Dawson, na.rn=T), lty=2)
boxplot(CarparkData$Trinity)
abline(h=mean(CarparkData$Trinity, na.rn=T), lty=2)
boxplot(CarparkData$Greenrcs)
abline(h=mean(CarparkData$Greenrcs, na.rn=T), lty=2)
boxplot(CarparkData$Drury)
abline(h=mean(CarparkData$Drury, na.rn=T), lty=2)
boxplot(CarparkData$BrownT)
abline(h=mean(CarparkData$BrownT, na.rn=T), lty=2)

#linear Model
library(lmtest)
data(CarparkData)
model <-lm(Ilac~Parnell, data=CarparkData)
bgtest(model)
Box.test(model$residuals, type="Ljung-Box", fitdf=1)
dwtest(model)

modelBS <-lm(BrownT~Setanta, data=CarparkData)
bgtest(modelBS)
Box.test(modelBS$residuals, type="Ljung-Box", fitdf=1)
dwtest(modelBS)

#Testing for stationarity
library(tseries)
library(forecast)
adf.test(CarparkData$Parnell)
kpss.test(CarparkData$Parnell)

adf.test(CarparkData$Ilac)
kpss.test(CarparkData$Ilac)

adf.test(CarparkData$Jervis)
kpss.test(CarparkData$Jervis)

adf.test(CarparkData$Arnotts)
kpss.test(CarparkData$Arnotts)

adf.test(CarparkData$Malboro)
kpss.test(CarparkData$Malboro)

adf.test(CarparkData$Thomas)
kpss.test(CarparkData$Thomas)

adf.test(CarparkData$ChristC)
kpss.test(CarparkData$ChristC)

adf.test(CarparkData$Setanta)
kpss.test(CarparkData$Setanta)

adf.test(CarparkData$Dawson)
kpss.test(CarparkData$Dawson)

adf.test(CarparkData$Trinity)
kpss.test(CarparkData$Trinity)

adf.test(CarparkData$Greenrcs)
kpss.test(CarparkData$Greenrcs)

adf.test(CarparkData$Drury)
kpss.test(CarparkData$Drury)

adf.test(CarparkData$BrownT)
kpss.test(CarparkData$BrownT)

#Decomposing Data
count_ma =ts(na.omit(CarparkData$Ilac), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$Parnell), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$Jervis), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$Arnotts), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)

count_ma =ts(na.omit(CarparkData$Malboro), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$Thomas), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$ChristC), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$Setanta), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$Dawson), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$Trinity), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$Greenrcs), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$Drury), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)

count_ma =ts(na.omit(CarparkData$BrownT), frequency = 30)
decomp = stl(count_ma, s.window="periodic")
deceasonal_cnt <-seasadj(decomp)
plot(decomp)
plot(decomp)

#Testing for Stationarity
adf.test(count_ma, alternative = "stationary")

#Autocorrections and choosing correct model
Acf(count_ma, main="")
Pacf(count_ma,main="")

count_d1 =diff(CarparkData$Parnell,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Parnell)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Ilac,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Ilac)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Jervis,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Jervis)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Arnotts,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Arnotts)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Malboro,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Malboro)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Thomas,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Thomas Street)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$ChristC,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Christ Church)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Setanta,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Setanta)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Dawson,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Dawson Street)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Trinity,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Trinity)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Greenrcs,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Greenrcs)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$Drury,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Drury)")
Pacf(count_d1,main="PACF for Differenced Series")

count_d1 =diff(CarparkData$BrownT,differences=1)
plot(count_d1)
adf.test(count_d1, alternative = "stationary")
Acf(count_d1,main="ACF for Differnced Series (Brown Thomas)")
Pacf(count_d1,main="PACF for Differenced Series")

#Fitting the ARIMA MODEL
auto.arima(deceasonal_cnt, seasonal=FALSE)

#Evaluate and Iterate
fit <-auto.arima(deceasonal_cnt,seasonal=FALSE)
tsdisplay(residuals(fit), lag.max=45,main="Model Residuals")
fcast <-forecast(fit, h=30)
plot(fcast)

#Multiple Regression
head(CarparkData)
pairs(CarparkData)
cor(CarparkData$Parnell, CarparkData$Jervis)
ml <- lm(CarparkData$Ilac ~CarparkData$Trinity)
summary(ml)
predict(ml,data.frame("Spaces"=40))

#Data Quality Report New
library(magrittr)
library(qwraps2)
#options(qwraps2_markup="markdown")
library(expss)
#cro(CarparkData$Parnell, CarparkData$Ilac)
#cro_cpct(CarparkData$Parnell, list(CarparkData$Jervis, CarparkData$Arnotts))
#CarparkData %>% calc_cro_cpct()

summary <-function(x){
  funs <- c(mean,median,sd,mad,IQR)
  lapply(funs,function(f) f(x, na.rm=TRUE))
}
sapply(CarparkData, function(x) {if(is.numeric(x)) summary(x)})
with(CarparkData, table(Parnell,Ilac))



#Testing
index <- sample(1:nrow(CarparkData), nrow(CarparkData)*0.75, replace = F)



training <- CarparkData[index, ]

testing <- CarparkData[-index, ]


#Checking the structure of the testing data 
str(testing)
#Checking the dimention of the testing data
dim(testing)
#Showing the first 3 rows of the testing data
head(testing,3)
#checking out the predictor variables
apply(testing,2,class)
#Check on the number of the unique values
apply(testing,2,function(t) round(length(unique(t))/nrow(testing),3)*100)

##Looking at the vaeiables
cols <-c("Parnell", "Jervis", "Ilac","Arnotts", "Malboro","Thomas","ChristC","Setanta","Dawson","Trinity","Greenrcs","Drury","BrownT")
for(i in cols){
  testing[,i]=as.factor(testing[,i])
}
str(testing)

#Check summary of each variable
#This will give min and max per variable
apply(testing,2,range)

